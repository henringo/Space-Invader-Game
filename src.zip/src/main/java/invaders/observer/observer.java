package invaders.observer;

public interface observer {
    void update(int num);
}
